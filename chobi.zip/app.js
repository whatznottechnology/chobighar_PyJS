// Standalone server for cPanel - doesn't need full node_modules
const { createServer } = require('http');
const { parse } = require('url');
const path = require('path');

const port = parseInt(process.env.PORT || '3000', 10);
const hostname = '0.0.0.0';

console.log('Starting Chobighar standalone server...');
console.log('Port:', port);

// Try to load Next.js
let next, app, handle;

try {
  next = require('next');
  app = next({ 
    dev: false, 
    hostname, 
    port,
    dir: __dirname
  });
  handle = app.getRequestHandler();
  
  app.prepare()
    .then(() => {
      console.log('✓ Next.js app ready');
      startServer();
    })
    .catch((err) => {
      console.error('Next.js prepare failed:', err.message);
      console.log('Trying standalone mode...');
      startStandalone();
    });
} catch (err) {
  console.error('Cannot load Next.js:', err.message);
  console.log('Starting in standalone mode...');
  startStandalone();
}

function startServer() {
  createServer(async (req, res) => {
    try {
      const parsedUrl = parse(req.url, true);
      await handle(req, res, parsedUrl);
    } catch (err) {
      console.error('Request error:', err.message);
      res.statusCode = 500;
      res.end('Internal server error');
    }
  })
  .listen(port, hostname, () => {
    console.log(`✓ Server running on http://${hostname}:${port}`);
    console.log('✓ Visit: app.chobighar.com');
  });
}

function startStandalone() {
  // Fallback standalone server
  const staticHandler = require('./node_modules/next/dist/server/lib/start-server').startServer;
  
  createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <!DOCTYPE html>
      <html>
        <head><title>Chobighar - Starting...</title></head>
        <body>
          <h1>Chobighar Application</h1>
          <p>Server is running but Next.js app is not ready.</p>
          <p>Please run: npm install --production</p>
        </body>
      </html>
    `);
  }).listen(port, hostname, () => {
    console.log(`Fallback server on ${hostname}:${port}`);
  });
}
