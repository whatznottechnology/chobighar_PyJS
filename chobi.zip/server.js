// Custom server.js for Namecheap cPanel Node.js hosting
const { createServer } = require('http');
const { parse } = require('url');
const next = require('next');

const dev = false; // Always production for cPanel
const hostname = '0.0.0.0'; // Listen on all interfaces for cPanel
const port = parseInt(process.env.PORT || '3000', 10);

console.log('=================================');
console.log('Starting Chobighar Next.js App');
console.log('=================================');
console.log('Environment:', process.env.NODE_ENV || 'production');
console.log('Port:', port);
console.log('Hostname:', hostname);
console.log('=================================');

// Initialize Next.js app
const app = next({ 
  dev, 
  hostname, 
  port,
  customServer: true
});

const handle = app.getRequestHandler();

app.prepare()
  .then(() => {
    console.log('✓ Next.js application prepared successfully');
    
    createServer(async (req, res) => {
      try {
        const parsedUrl = parse(req.url, true);
        await handle(req, res, parsedUrl);
      } catch (err) {
        console.error('Error occurred handling', req.url, err);
        res.statusCode = 500;
        res.end('Internal server error');
      }
    })
    .once('error', (err) => {
      console.error('Server error:', err);
      process.exit(1);
    })
    .listen(port, hostname, () => {
      console.log('=================================');
      console.log(`✓ Server listening on ${hostname}:${port}`);
      console.log('✓ Application ready at app.chobighar.com');
      console.log('=================================');
    });
  })
  .catch((err) => {
    console.error('Failed to start Next.js app:', err);
    process.exit(1);
  });
