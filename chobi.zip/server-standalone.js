// Standalone server for cPanel Node.js hosting
const { createServer } = require('http');
const { parse } = require('url');
const path = require('path');
const fs = require('fs');

const hostname = '0.0.0.0';
const port = parseInt(process.env.PORT || '3000', 10);

console.log('=================================');
console.log('Chobighar Standalone Server');
console.log('=================================');
console.log('Port:', port);
console.log('Hostname:', hostname);
console.log('Directory:', __dirname);

// Check if standalone build exists
const standaloneDir = path.join(__dirname, '.next/standalone');
const hasStandalone = fs.existsSync(standaloneDir);

console.log('Standalone build:', hasStandalone ? 'YES' : 'NO');

if (hasStandalone) {
  // Use standalone server
  process.chdir(standaloneDir);
  const standaloneServer = require('./.next/standalone/server.js');
  console.log('✓ Using Next.js standalone server');
} else {
  // Fallback to regular Next.js
  const next = require('next');
  
  const app = next({
    dev: false,
    hostname,
    port,
    dir: __dirname
  });
  
  const handle = app.getRequestHandler();
  
  app.prepare()
    .then(() => {
      console.log('✓ Next.js app prepared');
      
      createServer(async (req, res) => {
        try {
          const parsedUrl = parse(req.url, true);
          await handle(req, res, parsedUrl);
        } catch (err) {
          console.error('Request error:', err.message);
          res.statusCode = 500;
          res.end('Internal server error');
        }
      })
      .once('error', (err) => {
        console.error('Server error:', err);
        process.exit(1);
      })
      .listen(port, hostname, () => {
        console.log('=================================');
        console.log(`✓ Server running on ${hostname}:${port}`);
        console.log('✓ Visit: app.chobighar.com');
        console.log('=================================');
      });
    })
    .catch((err) => {
      console.error('Failed to start:', err);
      process.exit(1);
    });
}
