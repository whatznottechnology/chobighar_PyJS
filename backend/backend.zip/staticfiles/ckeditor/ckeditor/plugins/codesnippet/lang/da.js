﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","da",{button:"Indsæt kodestykket her",codeContents:"Koden",emptySnippetError:"Kodestykket kan ikke være tomt.",language:"Sprog",title:"Kodestykke",pathName:"kodestykke"});