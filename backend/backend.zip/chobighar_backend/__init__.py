"""
Chobighar Backend - Main Application
Automatic watermark system for all image uploads
"""
default_app_config = 'chobighar_backend.apps.ChobigharBackendConfig'
